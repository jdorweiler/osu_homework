
struct data {
    int number;
    char *name;
};
